

/**
 * Interface for route data
 */
export interface IRouteData {

  primaryNavIsVisible: boolean;

};
