import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { PolicyService, AppService } from '../../services';
import { IBasePolicy, IRouteData } from '../../interfaces';

@Component({
  selector: 'pl-dashboard',
  templateUrl: './dashboard.component.html'
})
export class DashboardComponent implements OnInit {
  title: string;
  policies: IBasePolicy[];

  constructor(private _policyService: PolicyService, private appService: AppService, private activatedRoute: ActivatedRoute) {
    this.title = 'Dashboard';

    // publish an event to update the primary nav visibility
    activatedRoute.data
      .subscribe((data: IRouteData) => {
        this.appService.updateNavVisibility(data.primaryNavIsVisible);
      });
  }

  ngOnInit() : void {
    this.findAllPolicies();
  }

  findAllPolicies() {
    this._policyService
        .getPolicies()
        .then(response => {
          this.policies = response;
          console.log('foundPolicies: ', JSON.stringify(response));
        });
  }

}
