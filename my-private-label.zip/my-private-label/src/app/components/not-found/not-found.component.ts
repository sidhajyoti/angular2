import { Component } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { AppService } from '../../services';
import { IRouteData } from '../../interfaces';

@Component({
  selector: 'pl-not-found',
  templateUrl: './not-found.component.html'
})
export class NotFoundComponent {
  brand: string;

  constructor(
    private appService: AppService,
    private activatedRoute: ActivatedRoute
  ) {
    this.brand = 'Sentry';

    // publish an event to update the primary nav visibility
    activatedRoute.data
      .subscribe((data: IRouteData) => {
        this.appService.updateNavVisibility(data.primaryNavIsVisible);
      });
  }
}
