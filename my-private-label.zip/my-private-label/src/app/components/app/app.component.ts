import { Component } from '@angular/core';
import { HeaderComponent } from '../header/header.component';
import { SideNavComponent } from '../side-nav/side-nav.component';

import { AppService } from '../../services';

@Component({
  selector: 'app',
  templateUrl: './app.component.html',
  providers: [ AppService ]
})
export class AppComponent {
  brand: string;
  primaryNavIsVisible: boolean = false;

  constructor(private appService: AppService) {
    this.brand = 'Sentry';
    this.appService
      .navStateChanged$
      .subscribe(v => {
        this.primaryNavIsVisible = v;
      });
  }

}
