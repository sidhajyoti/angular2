import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { HttpModule } from '@angular/http';

import {
  AppComponent,
  DashboardComponent,
  NotFoundComponent,
  BillingComponent,
  PoliciesComponent,
  ClaimsComponent,
  ContactComponent,
  SettingsComponent,
  SideNavComponent,
  DairylandFeedComponent,
  IdCardsComponent,
  PaymentsWidgetComponent,
  NeedHelpComponent,
  LoginComponent
} from '../components';
import { rootRouterConfig } from './app.routes';

import { PolicyService } from '../services';

@NgModule({
  imports : [
    BrowserModule,
    FormsModule,
    HttpModule,
    RouterModule.forRoot(rootRouterConfig) // creates the routing module
  ],
  declarations : [
    AppComponent,
    DashboardComponent,
    NotFoundComponent,
    BillingComponent,
    PoliciesComponent,
    ClaimsComponent,
    ContactComponent,
    SettingsComponent,
    SideNavComponent,
    DairylandFeedComponent,
    IdCardsComponent,
    PaymentsWidgetComponent,
    NeedHelpComponent,
    LoginComponent
  ],
  providers : [PolicyService],
  bootstrap : [AppComponent]
})
export class AppModule {

}
