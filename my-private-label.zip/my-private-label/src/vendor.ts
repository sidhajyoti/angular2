import '@angular/platform-browser-dynamic';
import '@angular/platform-browser';
import '@angular/core';
import '@angular/http';
import '@angular/router';

// we will have to import jquery in order to run bootstrap.js
// import 'jquery/dist/jquery.slim.min.js';
import 'bootstrap-sass/assets/javascripts/bootstrap.min';

// RxJS 5
// import 'rxjs/Rx';

// We are not importing all of rxjs, only the operators that we will use

// Statics
import 'rxjs/add/observable/throw';

// Operators
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/debounceTime';
import 'rxjs/add/operator/distinctUntilChanged';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/switchMap';
import 'rxjs/add/operator/toPromise';
