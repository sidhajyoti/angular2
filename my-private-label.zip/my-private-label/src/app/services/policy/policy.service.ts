import 'rxjs/add/operator/toPromise';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import {
  Response,
  Headers,
  RequestOptions,
  Http,
  RequestOptionsArgs
} from '@angular/http';

import { IBasePolicy } from '../../interfaces';

@Injectable()
export class PolicyService {

    private _policiesUrl: string = '/rest/v1/policies/';

    constructor(private _http: Http) { }

    /**
     * Finds all policies associated to the user and returns basic information about them
     *
     * GET {{base.url}}/rest/v1/simple-policy/{{policyNumber}}
     *
     */
    getPolicies() : Promise<IBasePolicy[]> {
        // return this._http.get(this._policiesUrl)
        //                   .toPromise()
        //                   .then( res => res.json() as IBasePolicy[] )
        //                   .catch( err => {
        //                     console.error(err);
        //                   });

        return Promise.resolve([{}, {}]);
    }

}
