import { Component } from '@angular/core';
import { Http, Headers } from '@angular/http';
import { ActivatedRoute } from '@angular/router';

import { AppService, LoginService, PolicyService } from '../../services';
import { IRouteData } from '../../interfaces';

@Component({
  selector: 'login',
  templateUrl: './login.component.html'
})
export class LoginComponent {
  title: string;
  localUser = {
        username: '',
        password: ''
      };

      constructor(private _policyService: PolicyService, private appService: AppService, private loginService: LoginService,  private activatedRoute: ActivatedRoute) {
        this.title = 'Login';
        console.log( 'Inside Constructor' );
  }
  login() {
    console.log( 'Inside Login()' );
    this._policyService.login( this.localUser ).then((res) => {
      if (res) {
        this._router.navigate([ 'Dashboard' ]);
      }
      else {
        alert ( 'Invalid credentials!!' );
        console.log( 'res' );
  }
})
}
}
