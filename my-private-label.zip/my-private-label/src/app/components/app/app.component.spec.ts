import {
  TestBed,
  inject,
  async,
  ComponentFixture
} from '@angular/core/testing';
import { provideRoutes } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';

// Load the implementations that should be tested
import { AppComponent } from './app.component';
import { PolicyService } from '../../services';
import { IBasePolicy } from '../../interfaces';





describe('App Component', () => {

  // provide our implementations or mocks to the dependency injector
   beforeEach(() => {
     TestBed.configureTestingModule({
       imports: [RouterTestingModule],
       declarations: [AppComponent],
       providers: [provideRoutes([])]
     });
     TestBed.compileComponents();
   });

  it ('should have a brand', () => {
    let fixture = TestBed.createComponent(AppComponent);
    expect(fixture.debugElement.componentInstance.brand).toEqual('Sentry');
  });

});

// import { beforeEachProviders, inject, it, addProviders, async } from '@angular/core/testing';

// Load the implementations that should be tested
// import { AppComponent } from './app.component';
//
// describe('App Component', () => {
//   // provide our implementations or mocks to the dependency injector
//   beforeEachProviders(() => [
//     AppComponent
//   ]);
//   it('should create the app',
//     inject([AppComponent], (app: AppComponent) => {
//       expect(app).toBeTruthy();
//     }));
//   it('should have a brand', inject([ AppComponent ], (app) => {
//     expect(app.brand).toEqual('Sentry');
//   }));
//
// });
