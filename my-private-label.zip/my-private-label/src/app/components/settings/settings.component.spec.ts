import {
  beforeEachProviders,
  inject,
  it
} from '@angular/core/testing';

// Load the implementations that should be tested
import { SettingsComponent } from './settings.component';

describe('Settings Component', () => {
  // provide our implementations or mocks to the dependency injector
  beforeEachProviders(() => [
    SettingsComponent
  ]);

  it('should have a title', inject([ SettingsComponent ], (app) => {
    expect(app.title).toEqual('Settings');
  }));

});
