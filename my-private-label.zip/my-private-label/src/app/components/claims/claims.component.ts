import { Component } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { AppService } from '../../services';
import { IRouteData } from '../../interfaces';

@Component({
  selector: 'pl-claims',
  templateUrl: './claims.component.html'
})
export class ClaimsComponent {

  constructor(
    private appService: AppService,
    private activatedRoute: ActivatedRoute
  ) {

    // publish an event to update the primary nav visibility
    activatedRoute.data
      .subscribe((data: IRouteData) => {
        this.appService.updateNavVisibility(data.primaryNavIsVisible);
      });
  }
}
