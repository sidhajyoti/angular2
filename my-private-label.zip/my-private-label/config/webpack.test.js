var webpack = require('webpack');

var helpers = require('./helpers');
var sentryConfig = require('./sentry.config.json');

var NODE_ENV = sentryConfig.nodeEnv;

module.exports = {
  devtool: 'inline-source-map',

  resolve: {
    extensions: ['', '.ts', '.js', '.html'],
    root: helpers.root('src'),
    modulesDirectories: ['node_modules']
  },

  module: {
    preloaders: [
      {
        test: /\.ts$/,
        loader: 'tslint-loader',
        exclude: /node_modules/
      },
      {
        test: /\.js$/,
        loader: 'source-map-loader',
        exclude: [
          // these packages have problems with their sourcemaps
          helpers.root('node_modules', 'rxjs'),
          helpers.root('node_modules', '@angular'),
        ]
      }
    ],

    loaders: [
      {
        test: /\.ts$/,
        loaders: ['awesome-typescript-loader?removeComments=true', 'angular2-template-loader'],
        exclude: [/\.e2e\.ts$/]
      },
      {
        test: /\.html$/,
        exclude: /node_modules/,
        loader: 'html-loader?attrs=false'
      }
    ],
    postLoaders: [
      {
        test: /\.(js|ts)$/, loader: 'istanbul-instrumenter-loader',
        include: helpers.root('src'),
        exclude: [
          /\.(e2e|spec|entry)\.ts$/,
          /node_modules/
        ]
      }

    ]
  },
  tslint: {
    emitErrors: false,
    failOnHint: false,
    resourcePath: '../src'
  },
  plugins: [
    new webpack.DefinePlugin({
      'process.env': {
        NODE_ENV: JSON.stringify(NODE_ENV)
      }
    })
  ],
  node: {
    global: 'window',
    process: false,
    crypto: 'empty',
    module: false,
    clearImmediate: false,
    setImmediate: false
  }
}
