import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { Subject }    from 'rxjs/Subject';

import { IRouteData, IBasePolicy } from '../../interfaces';

@Injectable()
export class AppService {

  public navStateChanged$: Observable<boolean>;
  private navDisplaySource = new Subject<boolean>();

  constructor() {
    this.navStateChanged$ = this.navDisplaySource.asObservable();
  }

  updateNavVisibility(shouldBeVisible: boolean) {
    this.navDisplaySource.next(shouldBeVisible);
  }
}
