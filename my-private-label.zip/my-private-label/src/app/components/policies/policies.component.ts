import { Component } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { AppService } from '../../services';
import { IRouteData } from '../../interfaces';

@Component({
  selector: 'pl-policies',
  templateUrl: './policies.component.html'
})
export class PoliciesComponent {

  constructor(
    private appService: AppService,
    private activatedRoute: ActivatedRoute
  ) {

    // publish an event to update the primary nav visibility
    activatedRoute.data
      .subscribe((data: IRouteData) => {
        this.appService.updateNavVisibility(data.primaryNavIsVisible);
      });
  }
}
