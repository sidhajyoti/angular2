import {
  beforeEachProviders,
  inject,
  it, addProviders, async
} from '@angular/core/testing';

// Load the implementations that should be tested
import { BillingComponent } from './billing.component';

describe('Billing Component', () => {
  // provide our implementations or mocks to the dependency injector
  beforeEachProviders(() => [
    BillingComponent
  ]);
  it('should create the app',
    inject([BillingComponent], (app: BillingComponent) => {
      expect(app).toBeTruthy();
    }));

  it('should have a title', inject([ BillingComponent ], (app) => {
    expect(app.title).toEqual('Billing');
  }));

});
