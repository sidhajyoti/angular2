import {
  beforeEachProviders,
  inject,
  it
} from '@angular/core/testing';

// Load the implementations that should be tested
import { ClaimsComponent } from './claims.component';

describe('Claims Component', () => {
  // provide our implementations or mocks to the dependency injector
  beforeEachProviders(() => [
    ClaimsComponent
  ]);

  it('should have a title', inject([ ClaimsComponent ], (app) => {
    expect(app.title).toEqual('Claims');
  }));

});
