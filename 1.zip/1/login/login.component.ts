import { Component } from '@angular/core';
import { Http, Headers } from '@angular/http';
import { ActivatedRoute, Router } from '@angular/router';

import { AppService, LoginService, PolicyService } from '../../services';
import { IRouteData, ICredentials } from '../../interfaces';

@Component({
  selector: 'login',
  providers: [LoginService],
  templateUrl: './login.component.html'
})
export class LoginComponent {
  title: string;

  username: string;
  password: string;

  constructor(private _policyService: PolicyService, private appService: AppService, private loginService: LoginService,  private activatedRoute: ActivatedRoute, private _router: Router) {
    this.title = 'Login';
    console.log( 'Inside Constructor' );
  }

  validateCredentials() {
    return (!!this.username || !!this.password);
  }
  onSubmit() {
    console.log('Username: %s, Password: %s', this.username, this.password);

    let credentials: ICredentials = {
      username: this.username,
      password: this.password
    };

    this.loginService.login( credentials ).then((res) => {
      if (res) {
        this._router.navigate([ '' ]);
      }
      else {
        alert ( 'Invalid credentials!!' );
        console.log( 'res' );
      }
    });
  }
}

// @Component({
//   selector: 'login',
//   providers: [LoginService],
//   templateUrl: './login.component.html'
// })
// export class LoginComponent {
//   title: string;
//   localUser = {
//         username: '',
//         password: ''
//       };
//
//       constructor( private _loginService: LoginService, private appService: AppService, private _policyService: PolicyService, private activatedRoute: ActivatedRoute, private _router: Router) {
//         this.title = 'Login';
//         console.log( 'Inside Constructor' );
//   }
//   login() {
//     console.log( 'Inside Login()' );
//     this._service.login( this.localUser ).then((res) => {
//       if (res) {
//         this._router.navigate([ 'pl-dashboard' ]);
//       }
//       else {
//         alert ( 'Invalid credentials!!' );
//         console.log( 'res' );
//   }
// });
// }
// }
