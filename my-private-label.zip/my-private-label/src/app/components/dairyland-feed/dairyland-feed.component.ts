import { Component } from '@angular/core';

@Component({
  selector: 'pl-dairyland-feed',
  templateUrl: './dairyland-feed.component.html'
})
export class DairylandFeedComponent {
  title = 'app works!';
}
