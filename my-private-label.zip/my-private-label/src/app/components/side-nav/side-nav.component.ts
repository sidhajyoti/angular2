import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'pl-side-nav',
  templateUrl: './side-nav.component.html'
})
export class SideNavComponent implements OnInit {
  brand: string;

  constructor() {
    this.brand = 'Sentry';
  }

  ngOnInit() {
    console.log('pl-side-nav initialized');
  }
}
