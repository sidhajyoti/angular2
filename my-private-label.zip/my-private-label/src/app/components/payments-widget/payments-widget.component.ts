import { Component } from '@angular/core';
import { PaymentsWidgetService } from '../../services';

@Component({
  providers: [PaymentsWidgetService],
  selector: 'pl-payments-widget',
  templateUrl: './payments-widget.component.html'
})
export class PaymentsWidgetComponent {
  brand: string;
}
