import { Component } from '@angular/core';

@Component({
  selector: 'pl-headers',
  templateUrl: './header.component.html'
})
export class HeaderComponent {
  title = 'header fill your content';
}
