/**
 * Policy information for the dashboard
 *
 */
export interface IBasePolicy {

    number: string;

    status: string;

    expirationDate: Date;

    effectiveDate: Date;

    productType: string;

    state: string;

    amountDue: number;

    paymentDueDate: Date;

    automaticPaymentsEnabled: boolean;

}
