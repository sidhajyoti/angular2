import { enableProdMode } from '@angular/core';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { enableDebugTools, disableDebugTools } from '@angular/platform-browser';

import { AppModule } from './app/modules/app.module';


// create the default componentRefWrapper that just returns the component
// let componentRefWrapper = function identity(value) { return value; };

if (process.env.NODE_ENV === 'production') {
  enableProdMode();
  disableDebugTools();
}
// else {
//
//   // re assign the componentRefWrapper to a function that enables Angular 2's
//   // debug tools
//   componentRefWrapper = function debugWrapper(value) {
//     enableDebugTools(value);
//     return value;
//   };
// }

platformBrowserDynamic()
  .bootstrapModule(AppModule) // bootsrap our module
  // .then(componentRefWrapper) // add debug tools or not
  .catch( err => console.error(err) ); // log errors
