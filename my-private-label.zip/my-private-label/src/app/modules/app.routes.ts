import { Routes } from '@angular/router';

// import the components we need for each route
import {
  DashboardComponent,
  NotFoundComponent,
  BillingComponent,
  PoliciesComponent,
  ClaimsComponent,
  ContactComponent,
  SettingsComponent,
  LoginComponent
} from '../components';

export const rootRouterConfig: Routes = [
  {
    path: '',
    data: { primaryNavIsVisible : true },
    children: [
      { path: '', component: DashboardComponent },
      { path: 'billing', component: BillingComponent },
      { path: 'policies', component: PoliciesComponent },
      { path: 'claims', component: ClaimsComponent },
      { path: 'contact', component: ContactComponent },
      { path: 'settings', component: SettingsComponent }
    ]
  },
  { path: 'login', component: LoginComponent, data: { primaryNavIsVisible : false } },
  { path: '**', component: NotFoundComponent, data: { primaryNavIsVisible : false } }
];
