/**
 * @author 078295
 *
 * This decorator should be used to format any url strings that would point to
 * the API. It's sort of a hack right now since Typescript currently does not
 * pass the PropertyDescriptor of the property due to the fact that it can't describe
 * the instance. @see https://www.typescriptlang.org/docs/handbook/decorators.html#property-decorators
 */

// default to the prod url
let baseUri = 'https://my.privatelabel.com/';

if (process.env.API_ENV === 'local') {
  baseUri = 'http://localhost.sentry.com/';
}
else if (process.env.API_ENV === 'dev' || process.env.API_ENV === 'development') {
  baseUri = 'https://mydev.privatelabel.com/';
}
else if (process.env.API_ENV === 'test') {
  baseUri = 'https://mytest.privatelabel.com/';
}
else if (process.env.API_ENV === 'qual') {
  baseUri = 'https://myqual.privatelabel.com/';
}

export let ApiUrl = function _apiUrl(target: any, propertyKey: string): any {

  return {
    configurable: false,
    enumerable: false,
    set(value) {
      this[`_${propertyKey}`] = value;
    },
    get() {
      return baseUri + this[`_${propertyKey}`];
    }
  };
};
