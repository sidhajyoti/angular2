import {
  TestBed,
  inject,
  addProviders,
  async
} from '@angular/core/testing';
import { provide } from '@angular/core';

// Load the implementations that should be tested
import { DashboardComponent } from './dashboard.component';
import { PolicyService } from '../../services';
import { MockPolicyService } from '../../services/policy/policy.service.spec';


describe('Dashboard Component', () => {

  let logStore = [];

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [DashboardComponent],
      providers: [provide(PolicyService, { useClass: MockPolicyService})]
    });

    console.log = (...args) => {
      logStore.push(args);
    };
  });

  describe('on load', () => {
    beforeEach(async(() => {
      TestBed.compileComponents();
    }));

    it('should have title Dashboard', async(() => {
      let fixture = TestBed.createComponent(DashboardComponent);
      fixture.detectChanges();
      let compiled = fixture.debugElement.nativeElement;
      expect(compiled.querySelector('h1').textContent).toEqual('Dashboard');
    }));

    it('should retrieve all policies', async(() => {
      let fixture = TestBed.createComponent(DashboardComponent);
      fixture.detectChanges();
      expect(logStore.length).toEqual(1);
      expect(logStore[0].length).toEqual(2);
      expect(logStore[0][1]).toEqual(JSON.stringify(MockPolicyService.mockPolicies));
    }));

  });
});

// import {
//   beforeEachProviders,
//   inject,
//   it
// } from '@angular/core/testing';
//
// // Load the implementations that should be tested
// import { DashboardComponent } from './dashboard.component';
//
// describe('Dashboard Component', () => {
//   // provide our implementations or mocks to the dependency injector
//   beforeEachProviders(() => [
//     DashboardComponent
//   ]);
//
//   it('should have a title', inject([ DashboardComponent ], (app) => {
//     expect(app.title).toEqual('Dashboard');
//   }));
//
// });
