import { Component } from '@angular/core';

@Component({
  selector: 'pl-id-cards',
  templateUrl: './id-cards.component.html'
})
export class IdCardsComponent {
  title = 'app works!';
}
