import { PolicyService } from './policy.service';
import { IBasePolicy } from '../../interfaces';


export class MockPolicyService extends PolicyService {

  public static mockPolicies: IBasePolicy[] = [{
    number: '123456789',
    status: 'test',
    expirationDate: new Date(),
    effectiveDate: new Date(),
    productType: 'Powersports',
    state: 'AZ',
    amountDue: 100,
    paymentDueDate: new Date(),
    automaticPaymentsEnabled: true
  },
  {
    number: '987654321',
    status: 'test',
    expirationDate: new Date(),
    effectiveDate: new Date(),
    productType: 'Auto',
    state: 'NV',
    amountDue: 88,
    paymentDueDate: new Date(),
    automaticPaymentsEnabled: false
  }];


  getPolicies() : Promise<IBasePolicy[]> {
    return Promise.resolve(MockPolicyService.mockPolicies);
  }
}
