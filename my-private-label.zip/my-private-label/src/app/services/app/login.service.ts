import {Injectable} from '@angular/core';
import {Http, Headers} from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { Subject }    from 'rxjs/Subject';

@Injectable()
export class LoginService {

    isLoggedin: boolean;

    constructor( private _http: Http ) {
    }
    login(usercreds) {
      this.isLoggedin = false;
      let headers = new Headers();
      let creds = 'name=' + usercreds.username + '&password=' + usercreds.password;
      headers.append('Content-Type', 'application/X-www-form-urlencoded');

      return new Promise((resolve) => {

        this._http.post('http://localhost:8888/', creds, {headers: headers}).subscribe((data) => {
          if (data.json().success) {
            window.localStorage.setItem( 'auth_key', data.json().token );
            this.isLoggedin = true;
          }
          resolve( this.isLoggedin );
        }
      );
    } );
  }
}
