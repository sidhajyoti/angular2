
/**
 * This file gets is the bundle that is used for testing.
 * Sort of like the polyfills or vendor file we load.
 * At the bottom we are importing the actual test files.
 */

require('core-js');
require('ts-helpers');

require('zone.js/dist/zone');
require('zone.js/dist/long-stack-trace-zone');
require('zone.js/dist/jasmine-patch');
require('zone.js/dist/async-test');
require('zone.js/dist/fake-async-test');
require('zone.js/dist/sync-test');

// Set up Angular2s testing tools
require('rxjs/add/observable/throw');

// Operators
require('rxjs/add/operator/catch');
require('rxjs/add/operator/debounceTime');
require('rxjs/add/operator/distinctUntilChanged');
require('rxjs/add/operator/map');
require('rxjs/add/operator/switchMap');
require('rxjs/add/operator/toPromise');

var test = require('@angular/core/testing');
var browser = require('@angular/platform-browser-dynamic/testing');

Error.stackTraceLimit = Infinity;

test.TestBed.initTestEnvironment(
  browser.BrowserDynamicTestingModule,
  browser.platformBrowserDynamicTesting()
);

// var testContext = require.context('../src', true, /\.spec\.ts/);
//
// function requireAll(requireContext) {
//   return requireContext.keys().map(requireContext);
// }
//
// // requires and returns all modules that match
// var modules = requireAll(testContext);
//


/*
 * Add all tests here.
 */

require('../src/app/components/app/app.component.spec.ts');
require('../src/app/components/dashboard/dashboard.component.spec.ts');
