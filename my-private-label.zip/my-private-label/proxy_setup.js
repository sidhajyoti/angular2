/**
 * @author 078295 <ricardo.lopez@sentry.com>
 */

var exec = require('child_process').exec;
var fs = require('fs');
var rl = require('readline');

// grab environment variables
var HTTP_PROXY = process.env.HTTP_PROXY || '';
var HTTPS_PROXY = process.env.HTTPS_PROXY || '';

// grab the first argument
var operation = (!!process.argv) ? process.argv[2] : '';

// used to test that the proxy is formatted correctly
var proxyREGEX = /^http:\/\/\d+:.+@webproxy.sentry.com(\/|:80|:80\/)?$/;
var proxyFormat = 'http://<userid>:<password>@webproxy.sentry.com:80';
var usernameREGEX = /^\d+$/;

var doneMessage = '';
var doneOps = 0;

var WARNING_MESSAGE = '\nThis script modifies your environment variables.'
                    + '\nThis means that you should restart your command window after running this script so that your command window session has access to the new variables.\n';

/**
 * Typings commands to set and unset the typings proxy
 */


/**
 * setTypingsConfig - creates the typings proxy config
 *
 * @param  {string} httpVal  the http proxy value
 * @param  {string} httpsVal the https proxy value
 * @param  {string} homeVal  the user home path
 */
function setTypingsConfig(httpVal, httpsVal, homeVal) {
  var confText = [
    'proxy=' + HTTP_PROXY,
    'rejectUnauthorized=false'
  ].join('\n');
  console.log('\nSetting up the Typings proxy...');

  writeTypingsConfig(homeVal+ '\\.typingsrc', confText)
}


/**
 * unsetTypingsConfig - clears the typings proxy config
 *
 * @param  {string} homeVal  the user home path
 */
function unsetTypingsConfig(homeVal) {
  console.log('\nRemoving the Typings proxy...');

  writeTypingsConfig(homeVal+ '\\.typingsrc', '')
}


/**
 * writeTypingsConfig - general function for writing the .typingsrc file
 *
 * @param  {string} file     the file location
 * @param  {string} confText the text to write to the file
 */
function writeTypingsConfig(file, confText) {
  fs.writeFile(file, confText, function(error) {
    if (error) {
      console.error("\nAn error occurred while configuring Typings proxy: ", error);
      return;
    }
    doneOps += 1;
    console.log('\nTypings proxy has been configured.');
    printDoneMessage()
  });
}

/**
 * Npm commands to set and unset the npm proxy
 */

/**
 * setNpmConfig - sets the npm proxy configuration
 *
 * @param  {string} httpVal  the http proxy value
 * @param  {string} httpsVal the https proxy value
 */
function setNpmConfig(httpVal, httpsVal) {
  var cmd = [
    'npm config set proxy ' + httpVal,
    'npm config set https-proxy ' + httpsVal,
    'npm config set strict-ssl false'
  ].join(' && ');
  console.log('\nSetting up the NPM proxy...');

  execNpmCommand(cmd);
}


/**
 * unsetNpmConfig - clears the npm proxy
 *
 */
function unsetNpmConfig() {
  var cmd = [
    'npm config rm proxy ',
    'npm config rm https-proxy ',
    'npm config rm strict-ssl'
  ].join(' && ');
  console.log('\nRemoving the NPM proxy...');

  execNpmCommand(cmd);
}

/**
 * execNpmCommand - general function for executing npm commands
 *
 * @param  {string} cmd the command string
 */
function execNpmCommand(cmd) {
  exec(cmd, function(error, stdout, stderr) {
    if (error) {
      console.error("\nAn error occurred while configuring NPM proxy: ", error);
      return;
    }
    doneOps += 1;
    console.log('\nNPM proxy has been configured.');
    printDoneMessage()
  });
}


/**
 * Utilities
 */


/**
 * getSecretStdinFn - creates and returns a function that masks the user input
 *
 * @param  {string} prompt      the prompt to use
 * @param  {Object} stdin       a reference to the current process stdin
 * @param  {Object} rlInterface a reference to the current readline interface
 * @return {function}             a new function to use to mask user input
 */
function getSecretStdinFn(prompt, stdin, rlInterface) {
  return function(char) {
      char = char + "";
      switch (char) {
          case "\n":
          case "\r":
          case "\u0004":
              break;
          default:
              process.stdout.write("\033[2K\033[200D" + prompt + Array(rlInterface.line.length+1).join("*"));
              break;
      }
  };
}

/**
 * ask - utility function to prompt the user with a question and pass the user response to the callback
 *
 * @param  {string} question the question to ask the user
 * @param  {boolean} isSecret indicator that will mask the input
 * @param  {function} callback the callback that will recieve the user's response
 */
function ask(question, isSecret, callback) {
  var r = rl.createInterface({
    input: process.stdin,
    output: process.stdout});
  var stdin = process.openStdin();
  var secretStdinFn;

  if (isSecret) {
    secretStdinFn = getSecretStdinFn(question.replace('\n',''), stdin, r);
    process.stdin.on("data", secretStdinFn);
  }

  r.question(question, function(answer) {
    if (isSecret) {
      r.history = r.history.slice(1);
      process.stdin.removeListener('data', secretStdinFn);
    }
    r.close();
    callback(null, answer);
  });
}


/**
 * verifyProxyVals - utility function to verify if the https and http proxy values are valid
 *
 * @param  {string} httpVal  the http proxy value
 * @param  {string} httpsVal the https proxy value
 * @return {boolean}          whether or not both values are valid
 */
function verifyProxyVals(httpVal, httpsVal) {
  if (!proxyREGEX.test(httpVal) || !proxyREGEX.test(httpsVal)) {
    console.log('\nPlease ensure that your HTTP_PROXY and/or HTTPS_PROXY variable(s) are formatted correctly. Here is the format (replace <userid> and <password> and userid should should only be numbers):\n', proxyFormat, '\n');
    return false;
  }

  return true;
}

/**
 * getHomeVal - utility function that attempts to retrieve the home path of the user
 *
 * @return {string}  the home path if is found; false otherwise
 */
function getHomeVal() {
  var homeVal = process.env.HOME || process.env.USER_HOME ||  process.env.USERPROFILE;

  if (!homeVal) {
    console.log('Unable to read your HOME environment variable. Please set either your HOME variable or USER_HOME.');
    return false;
  }

  return homeVal;
}


/**
 * printDoneMessage - utility method that prints the doneMessage once all operations are done
 *
 */
function printDoneMessage() {
  if (doneOps === 3) {
    console.log(doneMessage);
  }
}

/**
 * setEnvironmentVariables - sets HTTP_PROXY and HTTPS_PROXY environment variables
 *
 * @param  {string} httpVal  the value for the HTTP_PROXY environment variable
 * @param  {string} httpsVal the value for the HTTPS_PROXY environment variable
 * @param  {function} cb       a callback function for when the environment variables are set
 */
function setEnvironmentVariables(httpVal, httpsVal, cb) {
  var cmd = 'setx HTTP_PROXY ' + httpVal + ' && setx HTTPS_PROXY ' + httpsVal;

  console.log('\nConfiguring your environment variables...');
  exec(cmd, function(error, stdout, stderr) {
    if (error) {
      console.error("\nAn error occurred while setting your environment variables: ", error);
      return;
    }

    console.log('\nEnvironment variables configured.');
    doneOps += 1;
    printDoneMessage()
    cb(httpVal, httpsVal);
  });
}



/**
 * Proxy Activation
 */


/**
 * runProxySetups - entry point for the main proxy setup
 *
 * @param  {string} httpVal  the http proxy value
 * @param  {string} httpsVal the https proxy value
 */
function runProxySetups(httpVal, httpsVal) {

  var homeVal = getHomeVal();

  if (!homeVal) {
    return;
  }

  setNpmConfig(httpVal, httpsVal);
  setTypingsConfig(httpVal, httpsVal, homeVal);
}



/**
 * activateProxy - activates the user's proxy
 *
 */
function activateProxy() {
  console.log('\nActivating your proxy...');
  doneMessage = '\nDone activating.';
  var setHttp = !!HTTP_PROXY;
  var setHttps = !!HTTPS_PROXY;
  var username;
  var password;

  if (setHttp && setHttps) {

    if (!verifyProxyVals(HTTP_PROXY, HTTPS_PROXY)) {
      return;
    }

    runProxySetups(HTTP_PROXY, HTTPS_PROXY);
  }

  console.log('\nWe will configure your environment variable(s)');
  ask('\nPlease provide your username: ', false, function(err, _username) {
    username = _username;

    if (!usernameREGEX.test(username)) {
      console.log('\nYour username must be numeric.\nSorry, you\'re going to have to restart the process :(')
      return;
    }

    ask('\nPlease provide you password: ', true, function(err, _password) {
      password = encodeURIComponent(_password); // in case any special characters are used

      HTTP_PROXY = HTTPS_PROXY = 'http://' + username + ':' + password + '@webproxy.sentry.com:80/';
      setEnvironmentVariables(HTTP_PROXY, HTTPS_PROXY, runProxySetups);
    })
  });
}


/**
 * deactivateProxy - deactivates the user's proxy
 *
 */
function deactivateProxy() {
  console.log('\nDeactivating your proxy...');
  doneMessage = '\nDone deactivating.';
  var homeVal = getHomeVal();

  if (!homeVal) {
    return;
  }

  setEnvironmentVariables('""', '""', function() {
    unsetNpmConfig();
    unsetTypingsConfig(homeVal);
  });
}

// our main starts here
console.warn(WARNING_MESSAGE);
switch (operation) {
  case '-d':
  case 'deactivate':
    deactivateProxy();
    break;

  // default operation is activate
  case '-a':
  case 'activate':
  default:
    activateProxy();
}
