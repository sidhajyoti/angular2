import { Component } from '@angular/core';

@Component({
  selector: 'pl-need-help',
  templateUrl: './needhelp.component.html'
})
export class NeedHelpComponent {

}
